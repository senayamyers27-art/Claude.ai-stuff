# Upload these to your repo root

Drag everything in this folder into the repo root (`senayamyers27-art/Claude.ai-stuff`),
keeping the `icons/` folder as a folder. Final layout:

    reserve.html
    privacy.html
    support.html
    terms.html
    manifest.webmanifest
    sw.js
    icons/icon-192.png
    icons/icon-512.png
    icons/icon-maskable-512.png
    icons/apple-touch-icon.png
    screenshots/6.5in-01-tonight.png
    screenshots/6.5in-02-floor.png
    screenshots/6.5in-03-menu.png
    screenshots/6.5in-04-vip.png

Then add the nav links in `index.html`:

- desktop nav, after `<a href="#visit">Visit</a>`:  `<a href="reserve.html">App</a>`
- mobile nav, after its `<a href="#visit">Visit</a>`:  `<a href="reserve.html">App Preview</a>`

And in the footer's bottom line in `index.html`, next to the existing "Staff" link:

    <a href="privacy.html" style="color:inherit; text-decoration:underline;">Privacy</a>
    <a href="support.html" style="color:inherit; text-decoration:underline;">Support</a>
    <a href="terms.html" style="color:inherit; text-decoration:underline;">Terms</a>

The app links to `/privacy.html` and `/support.html` from its "You" screen. Both app
stores require a privacy URL **and** a support URL to resolve before they will accept a
submission — use:

    Privacy policy URL:  https://www.11elevendallas.com/privacy.html
    Support URL:         https://www.11elevendallas.com/support.html

Before you publish support.html, replace the placeholder host number `(214) 555-0111`
and the `hello@` / `events@` addresses with the real ones (they appear in the contact
grid at the top and the note at the bottom).

## Installing it on a phone

- **iPhone:** open the page in Safari → Share → Add to Home Screen.
- **Android:** Chrome shows an "Install app" prompt automatically.

It then opens full-screen with the 11:Eleven icon, and still opens with no signal.

## When you upload a new reserve.html

Change `CACHE` in `sw.js` (currently `11eleven-v5`) to `v3`, `v4`, and so on. Without that,
anyone who already installed the app keeps seeing the old version.

## The host view is behind a staff code

`reserve.html#host` now asks for a four-digit staff code before it shows tonight's book.
The code is **1111** — change `STAFF_PIN` in the app before you go live. It is a deterrent,
not security; anyone reading the page source can find it.

## Screen URLs

Every screen has its own address, so you can link straight to one:

    reserve.html#reserve   the date / party / time picker
    reserve.html#menu      bar & kitchen
    reserve.html#vip       VIP and bottle service
    reserve.html#wait      the walk-in list
    reserve.html#events    what is on
    reserve.html#host      the host view (staff only — no link to it in the app)

The manifest also registers Reserve, Walk in and Menu as long-press shortcuts on the
installed icon.

## Notes

- The paths in `manifest.webmanifest` and `sw.js` start with `/`, which assumes the
  site is at the domain root (`www.11elevendallas.com`). On the
  `github.io/Claude.ai-stuff/` URL they will 404 until the custom domain is live —
  the page still works, only installing does not.
- Install prompts require HTTPS. GitHub Pages gives you that; tick **Enforce HTTPS**
  in Settings → Pages.
- Nothing in the app actually books a table yet. The banner says so and links back
  to your SevenRooms form.
